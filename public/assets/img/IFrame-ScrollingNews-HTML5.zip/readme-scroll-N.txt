

SCROLLING NEWS WINDOW IFRAME ADD-ON

----------------------------------------------

UNZIP THIS FILE AND THEN OPEN THE help-ScrollingNews.html TO GET STARTED.

----------------------------------------------

COPYRIGHT � Allwebco Design Corporation
See the help-ScrollingNews.html for terms of use


Help for this add-on can be found at:

http://www.allwebco-templates.com/support/S_script_newsfeed.htm

http://www.allwebco-templates.com/support/S_script_IFrame-NewsScroll.htm
